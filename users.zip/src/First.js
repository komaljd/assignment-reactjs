import React, { Component } from 'react'

export default class First extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             userArr:[],
             filterbyname:[],
             filterbycity:[]
        }
    }

    componentDidMount=()=>{
        fetch("https://jsonplaceholder.typicode.com/users")
        .then(res=>res.json())
        .then((userData)=>{
            this.setState({userArr:userData});
            this.setState({filterbyname:userData}); 
            this.setState({filterbycity:userData});  
            console.log(userData)             
        })
        .catch((err)=>{console.log(err)})
    }

    searchByName=(name)=>{
        let tempusers=this.state.userArr.filter((user)=>{
            return user.name.toLowerCase().includes(name.toLowerCase());
        })

        this.setState({filterbyname:tempusers});

    }

    searcbyCity=(city)=>{
        let tempcity=this.state.userArr.filter((add)=>{
            return add.address.city.toLowerCase().includes(city.toLowerCase());
        })

        this.setState({filterbycity:tempcity});
    }
    
    render() {
        return (
            <div className="table-container">

              <div>
                  <h1>User Data</h1>
              </div>
                <input type="search" placeholder="Search By Name" 
                onChange={(e)=>{
                    this.searchByName(e.target.value);
                }}/>
                <input type="search" placeholder="Search By city" 
                onChange={(e)=>{
                    this.searcbyCity(e.target.value);
                }}/>

               {
                   this.state.filterbyname.map((user,index)=>{
                       return(
                        <div className="card" key={index}>
                            <h3>{user.name}</h3>
                            <p>{user.phone}</p>
                            <p>{user.email}</p>
                            <p>{user.address.city}</p>
                        </div>
                       )
                   })
               }
            </div>
        )
    }
}
