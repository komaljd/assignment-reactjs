import './App.css'; 
import First from './First';
// import Header from './page/Header';  
// import Footer from './page/Footer';

 function App() {
  return(
    <div className="App">
    <First />
    </div>
  )
}

export default App